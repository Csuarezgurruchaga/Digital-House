images_base_url = 'https://raw.githubusercontent.com/Digital-House-DATA/ds_blend_2021_img/master/'
common_base_path = '/media/paulati/Nuevo vol/paula/dh/2021/dsad_2021/common/'

