# Crea una lista de letras a partir de una palabra
def crea_lista(string):
    result = list(string)
    return result
    

# Crea una tupla de letras a partir de una palabra
def crea_tupla(string):
    result = tuple(string)
    return result